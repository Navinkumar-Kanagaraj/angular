export const environment = {
  production: false,
  apiKey: 'api key',
  apiUrl: 'http://api.openweathermap.org/data/2.5'
};